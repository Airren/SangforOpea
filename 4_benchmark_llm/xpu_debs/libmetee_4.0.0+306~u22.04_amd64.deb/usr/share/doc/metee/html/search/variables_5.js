var searchData=
[
  ['major_85',['major',['../structteeDriverVersion__t.html#a7bfc5836816dd695ac2fda8265c2fa20',1,'teeDriverVersion_t']]],
  ['maxmsglen_86',['maxMsgLen',['../struct__TEEHANDLE.html#ab1ad56ea68400148939194530fc736df',1,'_TEEHANDLE']]],
  ['minor_87',['minor',['../structteeDriverVersion__t.html#abe5bd02672abe9b052f759c329ec2c12',1,'teeDriverVersion_t']]]
];
