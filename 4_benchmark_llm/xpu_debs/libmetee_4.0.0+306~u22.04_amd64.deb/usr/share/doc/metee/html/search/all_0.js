var searchData=
[
  ['_5fteehandle_0',['_TEEHANDLE',['../struct__TEEHANDLE.html',1,'']]]
];
