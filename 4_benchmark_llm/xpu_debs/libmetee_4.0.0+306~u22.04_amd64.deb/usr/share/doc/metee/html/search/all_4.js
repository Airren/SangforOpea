var searchData=
[
  ['handle_5',['handle',['../struct__TEEHANDLE.html#ad68eb20af4bc19f91f60c9321c9882ad',1,'_TEEHANDLE::handle()'],['../structtee__device__address.html#a683fb3d0bb09dc3f02a846e6efbd2208',1,'tee_device_address::handle()']]],
  ['hotfix_6',['hotfix',['../structteeDriverVersion__t.html#ae025ef10f91c47faec3b058b8b016d72',1,'teeDriverVersion_t']]]
];
