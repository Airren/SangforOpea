var searchData=
[
  ['log_5fcallback_83',['log_callback',['../struct__TEEHANDLE.html#a4b5b59b73ae0fb4370e20bb5768ef326',1,'_TEEHANDLE']]],
  ['log_5flevel_84',['log_level',['../struct__TEEHANDLE.html#a92f28260c824aa3a1f0d26ab09710745',1,'_TEEHANDLE']]]
];
