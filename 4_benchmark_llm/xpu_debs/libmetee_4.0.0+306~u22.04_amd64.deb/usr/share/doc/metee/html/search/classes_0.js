var searchData=
[
  ['_5fteehandle_60',['_TEEHANDLE',['../struct__TEEHANDLE.html',1,'']]]
];
