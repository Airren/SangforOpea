var searchData=
[
  ['protcolver_88',['protcolVer',['../struct__TEEHANDLE.html#a12ec585bb0bbd940900c8b5f28db203d',1,'_TEEHANDLE']]]
];
