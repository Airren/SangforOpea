var searchData=
[
  ['protcolver_13',['protcolVer',['../struct__TEEHANDLE.html#a12ec585bb0bbd940900c8b5f28db203d',1,'_TEEHANDLE']]],
  ['pteehandle_14',['PTEEHANDLE',['../metee_8h.html#a3f6843022a314a9a4b1551354cc26e99',1,'metee.h']]]
];
